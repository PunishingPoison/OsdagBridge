"""Crash barrier package."""
