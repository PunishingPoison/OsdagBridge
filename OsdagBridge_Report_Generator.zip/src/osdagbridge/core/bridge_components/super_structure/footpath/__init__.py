"""Footpath component package."""
