"""Pier geometry stub."""
