"""Pedestal geometry stub."""
