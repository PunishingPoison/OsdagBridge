"""Bridge types registry."""
