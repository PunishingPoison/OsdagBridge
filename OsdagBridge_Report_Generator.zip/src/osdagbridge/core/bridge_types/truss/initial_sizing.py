"""truss initial sizing (stub)."""
