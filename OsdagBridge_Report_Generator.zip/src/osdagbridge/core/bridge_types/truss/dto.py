"""truss DTO (stub)."""
