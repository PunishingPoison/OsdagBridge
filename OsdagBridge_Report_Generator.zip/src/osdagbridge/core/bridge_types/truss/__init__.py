"""truss module."""
