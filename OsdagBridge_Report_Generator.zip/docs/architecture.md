# architecture.md

Documentation placeholder.
